print("""
      Q1_and_or  Q2_xor_andnot     Q3_hebbian_net Q4_discrete_hopfield_net
      Q5_Kohonen_self_organizing_maps  Q6_perceptron   Q7_lvq  Q8_bipolar_sigmoid  
      code  clustering  randomforest lightgbm ann modules whatsapp xgboost
      
      """)

